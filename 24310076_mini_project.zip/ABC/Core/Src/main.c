/* USER CODE BEGIN Header */
/**
 ******************************************************************************
 * @file           : main.c
 * @brief          : Main program body
 ******************************************************************************
 * @attention
 *
 * Copyright (c) 2026 STMicroelectronics.
 * All rights reserved.
 *
 * This software is licensed under terms that can be found in the LICENSE file
 * in the root directory of this software component.
 * If no LICENSE file comes with this software, it is provided AS-IS.
 *
 ******************************************************************************
 */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

#include "string.h"
#include "stdio.h"
#include <math.h>

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
I2C_HandleTypeDef hi2c1;

UART_HandleTypeDef huart2;

/* USER CODE BEGIN PV */

int16_t Accel_X_RAW;
int16_t Accel_Y_RAW;
int16_t Accel_Z_RAW;
float Ax;
float Ay;
float Az;

int16_t Gyro_X_RAW;
int16_t Gyro_Y_RAW;
int16_t Gyro_Z_RAW;

float Gx;
float Gy;
float Gz;

float Roll = 0.0f;
float Pitch = 0.0f;

float Roll_Offset = 0.0f;
float Pitch_Offset = 0.0f;

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_I2C1_Init(void);
/* USER CODE BEGIN PFP */

void calibration_sequence(void) {

	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5, GPIO_PIN_RESET);
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3, GPIO_PIN_RESET);
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_10, GPIO_PIN_RESET);

	for (int i = 0; i < 5; i++) {
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5, GPIO_PIN_SET);
		HAL_Delay(100);
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5, GPIO_PIN_RESET);

		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3, GPIO_PIN_SET);
		HAL_Delay(100);
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3, GPIO_PIN_RESET);

		HAL_GPIO_WritePin(GPIOA, GPIO_PIN_10, GPIO_PIN_SET);
		HAL_Delay(100);
		HAL_GPIO_WritePin(GPIOA, GPIO_PIN_10, GPIO_PIN_RESET);
	}

	for (int i = 0; i < 5; i++) {
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5, GPIO_PIN_SET);
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3, GPIO_PIN_SET);
		HAL_GPIO_WritePin(GPIOA, GPIO_PIN_10, GPIO_PIN_SET);

		HAL_Delay(100);

		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(GPIOA, GPIO_PIN_10, GPIO_PIN_RESET);

		HAL_Delay(100);
	}
}

void uart_print(char msg[]) {

	HAL_UART_Transmit(&huart2, (uint8_t*) msg, strlen(msg), 100);
}

int mpu_init(void) {
	HAL_StatusTypeDef status;
	uint8_t dev_add = (0x68 << 1);
	uint8_t who_am_i = 0;
	uint8_t data;
	char id_msg[64];

	status = HAL_I2C_Mem_Read(&hi2c1, dev_add, 0x75, I2C_MEMADD_SIZE_8BIT,
			&who_am_i, 1, 100);
	if (status != HAL_OK || (who_am_i != 0x68 && who_am_i != 0x70)) {
		snprintf(id_msg, sizeof(id_msg), "MPU WHO_AM_I Failed! (0x%02X)\r\n",
				who_am_i);
		uart_print(id_msg);
		return 0;
	}
	snprintf(id_msg, sizeof(id_msg), "MPU Detected (WHO_AM_I = 0x%02X)\r\n",
			who_am_i);
	uart_print(id_msg);

	data = 0x00;
	status = HAL_I2C_Mem_Write(&hi2c1, dev_add, 0x6B, I2C_MEMADD_SIZE_8BIT,
			&data, 1, 100);
	if (status == HAL_OK) {
		uart_print("PWR_MGMT_1 Write OK\r\n");
	} else {
		uart_print("PWR_MGMT_1 Write Failed\r\n");
		return 0;
	}
	HAL_Delay(100);


	data = 0x00;
	status = HAL_I2C_Mem_Write(&hi2c1, dev_add, 0x1C, I2C_MEMADD_SIZE_8BIT,
			&data, 1, 100);
	if (status == HAL_OK) {
		uart_print("ACCEL_CONFIG Write OK\r\n");
	} else {
		uart_print("ACCEL_CONFIG Write Failed\r\n");
		return 0;
	}
	HAL_Delay(100);


	data = 0x00;
	status = HAL_I2C_Mem_Write(&hi2c1, dev_add, 0x1B, I2C_MEMADD_SIZE_8BIT,
			&data, 1, 100);
	if (status == HAL_OK) {
		uart_print("GYRO_CONFIG Write OK\r\n");
	} else {
		uart_print("GYRO_CONFIG Write Failed\r\n");
		return 0;
	}
	HAL_Delay(100);

	return 1;
}

int MPU6500_Read_Accel(void) {
	uint8_t Rec_Data[6];
	uint8_t dev_add = (0x68 << 1);
	if (HAL_I2C_Mem_Read(&hi2c1, dev_add, 0x3B, 1, Rec_Data, 6, 100)
			!= HAL_OK) {
		return 0;
	}

	Accel_X_RAW = (int16_t) (Rec_Data[0] << 8 | Rec_Data[1]);
	Accel_Y_RAW = (int16_t) (Rec_Data[2] << 8 | Rec_Data[3]);
	Accel_Z_RAW = (int16_t) (Rec_Data[4] << 8 | Rec_Data[5]);

	Ax = (float) Accel_X_RAW / 16384.0f;
	Ay = (float) Accel_Y_RAW / 16384.0f;
	Az = (float) Accel_Z_RAW / 16384.0f;
	return 1;
}

int MPU6500_Read_Gyro(void) {
	uint8_t Rec_Data[6];
	uint8_t dev_add = (0x68 << 1);
	if (HAL_I2C_Mem_Read(&hi2c1, dev_add, 0x43, 1, Rec_Data, 6, 100)
			!= HAL_OK) {
		return 0;
	}

	Gyro_X_RAW = (int16_t) (Rec_Data[0] << 8 | Rec_Data[1]);
	Gyro_Y_RAW = (int16_t) (Rec_Data[2] << 8 | Rec_Data[3]);
	Gyro_Z_RAW = (int16_t) (Rec_Data[4] << 8 | Rec_Data[5]);

	Gx = (float) Gyro_X_RAW / 131.0f;
	Gy = (float) Gyro_Y_RAW / 131.0f;
	Gz = (float) Gyro_Z_RAW / 131.0f;
	return 1;
}

void MPU6500_Calculate_Angles(void) {
	Roll = atan2f(Ay, Az) * (180.0f / M_PI);
	Pitch = atan2f(-Ax, sqrtf(Ay * Ay + Az * Az)) * (180.0f / M_PI);
}

void angle_calibration_sequence(void) {
	float roll_sum = 0.0f;
	float pitch_sum = 0.0f;
	for (int i = 0; i < 100; i++) {
		MPU6500_Read_Accel();
		MPU6500_Read_Gyro();
		MPU6500_Calculate_Angles();
		roll_sum += Roll;
		pitch_sum += Pitch;
		HAL_Delay(10); // 100 samples * 10 ms = 1 second total calibration
	}
	Roll_Offset = roll_sum / 100.0f;
	Pitch_Offset = pitch_sum / 100.0f;
}

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
 * @brief  The application entry point.
 * @retval int
 */
int main(void) {
	/* USER CODE BEGIN 1 */

	/* USER CODE END 1 */

	/* MCU Configuration--------------------------------------------------------*/

	/* Reset of all peripherals, Initializes the Flash interface and the Systick. */
	HAL_Init();

	/* USER CODE BEGIN Init */

	/* USER CODE END Init */

	/* Configure the system clock */
	SystemClock_Config();

	/* USER CODE BEGIN SysInit */

	/* USER CODE END SysInit */

	/* Initialize all configured peripherals */
	MX_GPIO_Init();
	MX_USART2_UART_Init();
	MX_I2C1_Init();
	/* USER CODE BEGIN 2 */

	uart_print("Industrial Orientation and Motion Monitoring System\r\n");
	uart_print("INITIALIZING CALIBRATION SEQUENCE\r\n");
	mpu_init();
	calibration_sequence();
	angle_calibration_sequence();

	char msg[180];
	snprintf(msg, sizeof(msg), "Offsets -> Roll: %.2f, Pitch: %.2f\r\n",
			Roll_Offset, Pitch_Offset);
	uart_print(msg);


	uart_print("CALIBRATION SEQUENCE COMPLETED\r\n");

	uint32_t sample_count = 0;

	/* USER CODE END 2 */

	/* Infinite loop */
	/* USER CODE BEGIN WHILE */
	while (1) {

		/* USER CODE END WHILE */

		/* USER CODE BEGIN 3 */



			if (MPU6500_Read_Accel() && MPU6500_Read_Gyro()) {
				MPU6500_Calculate_Angles();

				float cal_roll = Roll - Roll_Offset;
				float cal_pitch = Pitch - Pitch_Offset;
				float max_tilt = fmaxf(fabsf(cal_roll), fabsf(cal_pitch));

				// Reset all LEDs before setting the active status LED
				HAL_GPIO_WritePin(GPIOA, GPIO_PIN_10 | LD2_Pin, GPIO_PIN_RESET);
				HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3 | GPIO_PIN_5,
						GPIO_PIN_RESET);

				char *status_str;
				if (max_tilt > 30.0f) {
					// Excessive Tilt -> PA10 + Onboard LD2 ON
					HAL_GPIO_WritePin(GPIOA, GPIO_PIN_10 | LD2_Pin,
							GPIO_PIN_SET);
					status_str = "ALERT";
				} else if (max_tilt > 15.0f) {
					// Moderate Tilt -> PB3 ON
					HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3, GPIO_PIN_SET);
					status_str = "WARN";
				} else {
					// Normal / Safe -> PB5 ON
					HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5, GPIO_PIN_SET);
					status_str = "OK";
				}

				snprintf(msg, sizeof(msg),
						"[%lu ms] Acc(g):%.2f,%.2f,%.2f | Gyro(dps):%.2f,%.2f,%.2f | Roll:%.2f, Pitch:%.2f | %s\r\n",
						sample_count * 100, Ax, Ay, Az, Gx, Gy, Gz, cal_roll,
						cal_pitch, status_str);
				uart_print(msg);
			} else {
				uart_print("I2C Read Error\r\n");
			}

			sample_count++;
			HAL_Delay(100);
		}

	/* USER CODE END 3 */
}

/**
 * @brief System Clock Configuration
 * @retval None
 */
void SystemClock_Config(void) {
	RCC_OscInitTypeDef RCC_OscInitStruct = { 0 };
	RCC_ClkInitTypeDef RCC_ClkInitStruct = { 0 };

	/** Configure the main internal regulator output voltage
	 */
	__HAL_RCC_PWR_CLK_ENABLE();
	__HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE3);

	/** Initializes the RCC Oscillators according to the specified parameters
	 * in the RCC_OscInitTypeDef structure.
	 */
	RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
	RCC_OscInitStruct.HSIState = RCC_HSI_ON;
	RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
	RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
	RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
	RCC_OscInitStruct.PLL.PLLM = 16;
	RCC_OscInitStruct.PLL.PLLN = 336;
	RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV4;
	RCC_OscInitStruct.PLL.PLLQ = 2;
	RCC_OscInitStruct.PLL.PLLR = 2;
	if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK) {
		Error_Handler();
	}

	/** Initializes the CPU, AHB and APB buses clocks
	 */
	RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK
			| RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2;
	RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
	RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
	RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
	RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

	if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK) {
		Error_Handler();
	}
}

/**
 * @brief I2C1 Initialization Function
 * @param None
 * @retval None
 */
static void MX_I2C1_Init(void) {

	/* USER CODE BEGIN I2C1_Init 0 */

	/* USER CODE END I2C1_Init 0 */

	/* USER CODE BEGIN I2C1_Init 1 */

	/* USER CODE END I2C1_Init 1 */
	hi2c1.Instance = I2C1;
	hi2c1.Init.ClockSpeed = 100000;
	hi2c1.Init.DutyCycle = I2C_DUTYCYCLE_2;
	hi2c1.Init.OwnAddress1 = 0;
	hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
	hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
	hi2c1.Init.OwnAddress2 = 0;
	hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
	hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
	if (HAL_I2C_Init(&hi2c1) != HAL_OK) {
		Error_Handler();
	}
	/* USER CODE BEGIN I2C1_Init 2 */

	/* USER CODE END I2C1_Init 2 */

}

/**
 * @brief USART2 Initialization Function
 * @param None
 * @retval None
 */
static void MX_USART2_UART_Init(void) {

	/* USER CODE BEGIN USART2_Init 0 */

	/* USER CODE END USART2_Init 0 */

	/* USER CODE BEGIN USART2_Init 1 */

	/* USER CODE END USART2_Init 1 */
	huart2.Instance = USART2;
	huart2.Init.BaudRate = 115200;
	huart2.Init.WordLength = UART_WORDLENGTH_8B;
	huart2.Init.StopBits = UART_STOPBITS_1;
	huart2.Init.Parity = UART_PARITY_NONE;
	huart2.Init.Mode = UART_MODE_TX_RX;
	huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
	huart2.Init.OverSampling = UART_OVERSAMPLING_16;
	if (HAL_UART_Init(&huart2) != HAL_OK) {
		Error_Handler();
	}
	/* USER CODE BEGIN USART2_Init 2 */

	/* USER CODE END USART2_Init 2 */

}

/**
 * @brief GPIO Initialization Function
 * @param None
 * @retval None
 */
static void MX_GPIO_Init(void) {
	GPIO_InitTypeDef GPIO_InitStruct = { 0 };
	/* USER CODE BEGIN MX_GPIO_Init_1 */
	/* USER CODE END MX_GPIO_Init_1 */

	/* GPIO Ports Clock Enable */
	__HAL_RCC_GPIOC_CLK_ENABLE();
	__HAL_RCC_GPIOH_CLK_ENABLE();
	__HAL_RCC_GPIOA_CLK_ENABLE();
	__HAL_RCC_GPIOB_CLK_ENABLE();

	/*Configure GPIO pin Output Level */
	HAL_GPIO_WritePin(GPIOA, LD2_Pin | GPIO_PIN_10, GPIO_PIN_RESET);

	/*Configure GPIO pin Output Level */
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3 | GPIO_PIN_5, GPIO_PIN_RESET);

	/*Configure GPIO pin : B1_Pin */
	GPIO_InitStruct.Pin = B1_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	HAL_GPIO_Init(B1_GPIO_Port, &GPIO_InitStruct);

	/*Configure GPIO pins : LD2_Pin PA10 */
	GPIO_InitStruct.Pin = LD2_Pin | GPIO_PIN_10;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

	/*Configure GPIO pins : PB3 PB5 */
	GPIO_InitStruct.Pin = GPIO_PIN_3 | GPIO_PIN_5;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

	/* USER CODE BEGIN MX_GPIO_Init_2 */
	/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
 * @brief  This function is executed in case of error occurrence.
 * @retval None
 */
void Error_Handler(void) {
	/* USER CODE BEGIN Error_Handler_Debug */
	/* User can add his own implementation to report the HAL error return state */
	__disable_irq();
	while (1) {
	}
	/* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
 * @brief  Reports the name of the source file and the source line number
 *         where the assert_param error has occurred.
 * @param  file: pointer to the source file name
 * @param  line: assert_param error line source number
 * @retval None
 */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
